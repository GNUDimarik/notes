find ./ogl-es/source/ -name "$1.cpp" -exec cp {} project/jni/ \;
find ./ogl-es/source/ -name "$1.h" -exec cp {} project/jni/ \;
